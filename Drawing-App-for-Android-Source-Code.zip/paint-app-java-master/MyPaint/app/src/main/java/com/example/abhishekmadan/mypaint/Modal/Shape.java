package com.example.abhishekmadan.mypaint.Modal;

/**
 * Super class for all the Shape Modal class
 */
public class Shape {

    public Shape() {
    }
}
